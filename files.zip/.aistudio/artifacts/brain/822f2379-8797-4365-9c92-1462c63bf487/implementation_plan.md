# Pure Garment Cloth Multi-Zone Sampling for Graphic T-Shirts

## Summary
Upgrade the computer-vision color extraction engine with 5-zone pure garment cloth localization (shoulders, sleeves, collar, side flanks, and lower hem) while actively suppressing central graphic prints (such as large movie, streetwear, and artwork boxes). This guarantees that distinct shirt colors (such as Pink, White, and Black graphic tees) are accurately recognized by their authentic textile fabric and strictly separated into their own variant cards.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions were clarified and confirmed with the user in Phase 1:
> - **Pure Cloth Isolation Strategy**: Confirmed **Sample shoulders, sleeves, and collar to isolate pure garment cloth** rather than sampling the chest artwork.
> - **Variant Separation Rule**: Confirmed **Strictly separate each distinct cloth color into its own card**.

- **Confirmed Decision 1**: Exclude central graphic print box ($x: 26\%\text{--}74\%, y: 22\%\text{--}68\%$) with near-zero weight ($0.05\times$) so graphic artwork colors never pollute garment fabric extraction.
- **Confirmed Decision 2**: Distribute sampling weight across guaranteed pure cloth zones: Shoulders ($3.5\times$), Sleeves ($3.5\times$), Collar ($2.5\times$), Outer Torso Flanks ($3.0\times$), and Lower Hem ($2.5\times$).
- **Confirmed Decision 3**: Preserve 2-pass strict Delta-E clustering ($\Delta E \le 9.2$) and centroid guards so Pink, White, Black, and Navy never merge together.

---

## 1. Overview & Core Concept

- **What It Does**: Processes uploaded batches of graphic tees and standard garments by dynamically identifying the outer background, isolating the garment cloth across 5 peripheral pure-fabric zones, completely avoiding graphic artwork prints, and automatically generating individual color variant cards with precise retail fashion names.
- **Target Audience / Persona**: E-commerce apparel merchants, fashion boutique owners, and merchandise sellers uploading bulk graphic tees and apparel catalogs.
- **Key Value**: 100% automated garment variant creation without false merges caused by chest artwork, logos, or diverse photography backgrounds (white studio, wooden table, grey backdrop).

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. User selects or drops multiple product photos (e.g. 8–20 t-shirts, including graphic tees with identical or different prints).
  2. The system dynamically detects the backdrop color from the photo perimeter (handles studio white, wood, colored surfaces).
  3. The 5-zone fabric sampler analyzes the sleeves, shoulders, collar, and flanks, bypassing the chest graphic.
  4. Instant variant cards appear with exact retail color chips, English & Arabic names (e.g., "وردي فاتح / Light Pink", "أبيض ناصع / Pure White", "أسود / Black"), and assigned images.

```
┌─────────────────────────────────────────────────────────────┐
│ 5-Zone Pure Garment Cloth Localization Architecture          │
└─────────────────────────────────────────────────────────────┘

                  ┌──────── Collar Zone ────────┐
                  │    (x: 40-60%, y: 10-18%)   │
                  ▼                             ▼
         ┌────────────────┐             ┌────────────────┐
         │ Left Shoulder  │             │ Right Shoulder │
         │ (18-36%,12-24%)│             │ (64-82%,12-24%)│
         └───────┬────────┘             └────────┬───────┘
                 │                               │
┌────────────────▼────────┐ [ Graphic Print ] ┌──▼───────────────┐
│ Left Sleeve Fold        │ (26-74%, 22-68%)  │ Right Sleeve Fold│
│ (8-24%, 22-48%)         │ ◄── EXCLUDED ──►  │ (76-92%, 22-48%) │
└────────────────┬────────┘ (weight = 0.05x)  └──┬───────────────┘
                 │                               │
         ┌───────▼────────┐             ┌────────▼───────┐
         │ Left Flank     │             │ Right Flank    │
         │ (14-26%,34-72%)│             │ (74-86%,34-72%)│
         └───────┬────────┘             └────────┬───────┘
                 │                               │
                 └────────── Bottom Hem ─────────┘
                      (x: 25-75%, y: 74-92%)
```

- **Visual Theme & Feedback**:
  - Color chips in the variant builder reflect the pure cloth color with high-contrast borders for whites/light colors.
  - Informative toast confirms exact detected colors: e.g. "تم فرز 8 قمصان إلى 3 ألوان مختلفة بنجاح".

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Sampling 5 Peripheral Zones vs Full-Body Histogram**
  - *Chosen Approach*: Sample shoulders, sleeves, collar, flanks, and lower hem while giving the central rectangular graphic zone minimal weight ($0.05\times$).
  - *Why*: On graphic t-shirts (e.g., movie merch, band shirts, streetwear), chest prints often cover 50% or more of the torso with contrasting colors (e.g. black photo print on a pink shirt). Peripheral zones are physically guaranteed to be pure fabric.
  - *Alternatives Considered*: K-Means clustering on the whole torso was considered, but graphic prints with high pixel counts regularly out-voted subtle fabric colors like dusty rose or beige.

- **Decision 2: Retaining 2-Pass Double-Check Clustered Centroid Validation**
  - *Chosen Approach*: Keep the strict perceptual Delta-E threshold ($\Delta E \le 9.2$) and category protection rules (Black vs Navy vs Grey vs Pink).
  - *Why*: Prevents subtle garment shade differences from collapsing into single variants when batch uploading up to 20 images.

---

## 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────┐
│ High-Precision Color Pipeline Flow                          │
└─────────────────────────────────────────────────────────────┘
  Raw Image File (e.g. Pink Blade Runner Tee)
       │
       ▼
  [ Canvas Resample (64x64 offscreen) ]
       │
       ├──► Border Perimeter Analysis ──► Dynamic Background Color (bgLab)
       │
       ├──► 5-Zone Fabric Cloth Mask ──► Shoulders + Sleeves + Collar + Flanks
       │                                 (Chest Graphic Box Excluded)
       │
       ├──► Background Subtraction (Delta-E > 12.5 from bgLab)
       │
       ▼
  Weighted CIELAB Cloth Histogram ──► Primary Garment Fabric Hex & Lab
       │
       ▼
  2-Pass Strict Centroid Clustering (Delta-E <= 9.2)
       │
       ▼
  Variant Splitter ──► Creates Separate Variant Card for Each Cloth Color
```

### Key Technical Modifications in `src/utils/colorExtraction.ts`
1. **`getGarmentZoneWeight(xRatio, yRatio)`**:
   - Computes spatial coordinate weights for the 5 pure fabric regions.
   - Dampens the central chest zone ($x \in [0.26, 0.74], y \in [0.22, 0.68]$) to $0.05$.
   - Boosts shoulders, sleeves, flanks, collar, and hem to $2.5\times\text{--}3.5\times$.
2. **Dynamic Background Rejection**:
   - Rejects pixels matching the perimeter backdrop ($\Delta E \le 12.5$).
3. **White Shirt Disambiguation**:
   - Analyzes light neutral cloth specifically in the pure cloth zones ($L^* \ge 78$, chroma $\le 12$).
4. **Integration**:
   - Fully automated inside `handleVariantImageDrop`, `handleBaseImageDrop`, and `handleBulkMagicUpload`.
